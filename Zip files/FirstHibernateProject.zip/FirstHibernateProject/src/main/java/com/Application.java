package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.model.Employee;
import com.util.HibernateUtil;

public class Application {
	
	public static void main(String[] args) {
		
		getData();
		
	}

	private static void insertData() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Employee emp = new Employee("jsdbbsjb@gmail.com", 29000);
		
		session.beginTransaction();
		
		session.persist(emp);
		
		session.getTransaction().commit();
		
		System.out.println("Inserted....");
	}
	
	public static void getData() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Employee employee = session.find(Employee.class, 2);
		
		System.out.println(employee);
	}
	
	public static void updateData() {
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Employee emp = session.find(Employee.class, 1);
		emp.setSalary(40000);
		
		session.beginTransaction();
		
		//session.merge(emp);
		
		session.getTransaction().commit();
		
		session.close();
		
	}
	
	public static void deleteData() {
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		
		Session session = sessionFactory.openSession();
		Employee emp = new Employee(12,"",0);
		
		session.beginTransaction();
		
		session.remove(emp);
		
		session.getTransaction().commit();
	}
	
	
	
	
	

}
