package com.states;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.Employee;
import com.util.HibernateUtil;

public class States {
	
	public static void main(String[] args) {
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		
		Employee emp = new Employee(11,"wer@gmail.com",25000); // Transient
		Employee emp2 = new Employee(13,"dfd@gmail.com",23456);
		emp2.setSalary(10000);
		Session session = sessionFactory.openSession();
		
		session.beginTransaction();
		session.persist(emp); // Persistent
		
		emp.setSalary(30000);
		
		session.getTransaction().commit();
		
		session.close();
		
		emp.setSalary(24000); // Detached
		
		
	}

}
