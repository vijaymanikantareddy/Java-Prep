package com.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
	
	
	public static void main(String[] args) {
		
		List<Integer> nums = new ArrayList<>(Arrays.asList(10,10 , 10 ,21,30,27,4,17));
		
		// for
		
		// for each
		
		// Iterator / list iterator
		
		nums.forEach((n) -> System.out.println(n));
		
		List<Integer> even = nums
							.stream()
							.filter((n) -> n%2 == 0) // Intermediatte
							.collect(Collectors.toList()); // Terminal
			
		
		System.out.println(even);
		
		List<Integer> sortedList = nums
									.stream()
									.sorted(Comparator.reverseOrder())
									.toList();
		System.out.println(sortedList);
		
		
		
		
		
		List<Employee> employees = new ArrayList<Employee>();
		
		employees.add(new Employee(1, "Fayaz", 1000));
		employees.add(new Employee(2, "Ramu", 110000));
		employees.add(new Employee(3, "Upendar", 99999));
		employees.add(new Employee(4, "Vijay", 350000));
		
		
		// 100000
		employees
			.stream()
			.filter(emp -> emp.salary > 100000)
			.collect(Collectors.toList())
			.forEach(emp -> System.out.println(emp));
		
		List<Employee> sortedEmployees = employees
			.stream()
			.sorted((emp1, emp2) -> Integer.compare(emp2.salary,emp1.salary))
			.toList();
		
		System.out.println(sortedEmployees);
		
		List<Employee> salaries = employees
		.stream()
		.map((emp) -> new Employee(emp.id ,emp.name, (emp.salary+=5000)))
		.toList();
		
		System.out.println(salaries);
		
		
		List<Employee> names = employees
		.stream()
		.filter(emp -> emp.name.startsWith("F"))
		.toList();
		
		System.out.println(names);
		
		
		System.out.println(nums);
		List<Integer> unique = nums
			.stream()
			.distinct()
			.toList();
		System.out.println(unique);
		
		
		Integer integer = nums
			.stream()
			.sorted(Comparator.reverseOrder())
			.findFirst()
			.get();
		System.out.println(integer);
		
		
		Integer secondHighest = nums
			.stream()
			.distinct()
			.sorted(Comparator.reverseOrder())
			.skip(2)
			.findFirst()
			.get();
		System.out.println(secondHighest);
	}

}
