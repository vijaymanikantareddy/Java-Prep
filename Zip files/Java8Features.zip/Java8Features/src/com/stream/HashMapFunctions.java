package com.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.Set;
import java.util.stream.Collectors;

public class HashMapFunctions {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> names = new HashMap<Integer, String>();
		
		names.put(1, "Fayaz");
		names.put(2, "Mohan");
		names.put(3, "Nani");
		names.put(0, "Varma");
		names
			.entrySet()
			.stream()
			.forEach(entry -> System.out.println(entry.getKey() + " - " + entry.getValue()));
	
		Set<Integer> keys = names
			.keySet()
			.stream()
			.collect(Collectors.toSet());
		System.out.println(keys);
		
		names
			.values()
			.stream()
			.forEach(val -> System.out.println(val));
		
		Map<Integer, String> filteredMap = names
			.entrySet()
			.stream()
			.filter(entry -> entry.getKey() >= 2)
			.collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
		
		System.out.println(filteredMap);
		
		
		// 
		Map<String,String> courses = new HashMap<String, String>();
		courses.put("String1", "Course1");
		courses.put("String2", "Course2");
		courses.put("String3", "Course1");
		courses.put("String4", "Course1");
		
		 Map<String, String> filtered = courses
			.entrySet()
			.stream()
			.filter(entry -> entry.getValue().equals("Course1"))
			.collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
		
		System.out.println(filtered);
		
		List<Integer> list = new ArrayList<Integer>(Arrays.asList(10 , 13 , 17 , 20 , 24));
		
		long count = list
			.stream()
			.filter(n -> n%2 == 0)
			.count();
		
		System.out.println(count);
		
		int sum = list
			.stream()
			.mapToInt(n -> n)
			.sum(); // Integer - dint
		System.out.println(sum);
		
		List<Integer> fiveMultiples = list
			.stream()
			.filter(n -> n%5==0)
			.toList();
		
		System.out.println(fiveMultiples);
		
		int evenSum = list
				.stream()
				.filter(n -> n%2==0)
				.mapToInt(n -> n)
				.sum();
		
		System.out.println(evenSum);
		
		double asDouble = list
			.stream()
			.mapToInt(n -> n)
			.average()
			.getAsDouble();
		System.out.println(asDouble);
		
		
		int max = list
			.stream()
			.mapToInt(n -> n)
			.max()
			.getAsInt();
		
		System.out.println(max);
		
		int min = list
				.stream()
				.mapToInt(n -> n)
				.min()
				.getAsInt();
		
		System.out.println(min);
		
		
		List<List<String>> words = new ArrayList<List<String>>();
		
		words.add(Arrays.asList("Hi","Bye"));
		words.add(Arrays.asList("One","Two"));
		words.add(Arrays.asList("Gm","Gn"));
		System.out.println(words);
		
		List<String> result = words
			.stream()
			.flatMap(li -> li.stream())
			.toList();
		
		System.out.println(result);
		System.out.println("-----------");
		List<Integer> list2 = new ArrayList<Integer>(Arrays.asList(10 , 13 , 17 , 20 , 24));
		
		list2
			.stream()
			.forEach(n -> System.out.println(n));
		
		System.out.println("-------------");
		list2
			.parallelStream()
			.forEach(n -> System.out.println(n));
		System.out.println("------------");
		list2
			.stream()
			.limit(1)
			.forEach(n -> System.out.println(n));
		
		boolean allMatch = list2
			.stream()
			.allMatch(n -> n>0);
		System.out.println(allMatch);
			
		Optional<String> of = Optional.of("Fayaz");
		of.ifPresent((str) -> System.out.println(str));
	}

}
