package com.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test2 {
	
	
	public static void main(String[] args) {
		
		List<Integer> nums = new ArrayList<Integer>(Arrays.asList(1, 2 ,3,4,5));
		
		Integer sum = nums
			.stream()
			.reduce(0 , (a,b) -> a+b);
		
		System.out.println(sum);
		
		Integer product = nums
			.stream()
			.reduce(1 , (a,b) -> a*b);
		
		System.out.println(product);
		
		List<String> words = new ArrayList<String>(Arrays.asList("Fayaz" , "is","a","Java","Trainer"));
		
		String finalString = words
			.stream()
			.reduce( "", (a,b) -> a + " " + b );
		System.out.println(finalString.trim());
	}
}
