package com.compare;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

public class Test {
	
	
	public static void main(String[] args) {
		
		List<Student> students = new ArrayList<Student>();
		
		students.add(new Student(10,"XXXXX"));
		students.add(new Student(2,"YYYYY"));
		students.add(new Student(30,"ZZZZZ"));
		students.add(new Student(12,"TTTTT"));
		
		System.out.println(students);
		
		Collections.sort(students);
		
		System.out.println(students);
		
		
		List<Employee> employees = new ArrayList<Employee>();
		
		employees.add(new Employee(234,"Java","Fayaz"));
		employees.add(new Employee(123,"Python","Harish"));
		employees.add(new Employee(456,"C","Srikar"));
		employees.add(new Employee(109,"Ruby","Sowmya"));
		System.out.println(employees);
		Collections.sort(employees , new IdComparator());
		System.out.println(employees);
		
		Collections.sort(employees , new NameComparator());
		System.out.println(employees);
		
		
		Comparator<Employee> companyComparator = new Comparator<Employee>() {
			
			@Override
			public int compare(Employee emp1, Employee emp2) {
				return emp1.domain.compareTo(emp2.domain);
			}
		};
		
		Collections.sort(employees , companyComparator);
		System.out.println(employees);
		
		
		Comparator<Employee> idComparartor = (Employee e1 , Employee e2) -> { return Integer.compare(e1.empId, e2.empId);};
		Collections.sort(employees , idComparartor);
		System.out.println(employees);
		
		Collections.sort(employees , (e1,e2) -> e1.domain.compareTo(e2.domain) );
		System.out.println(employees);
		
		TreeSet<Employee> empSet = new TreeSet<Employee>((e1 , e2) -> e1.empName.compareTo(e2.empName));
		empSet.add(new Employee(234,"Java","Fayaz"));
		empSet.add(new Employee(123,"Python","Harish"));
		empSet.add(new Employee(456,"C","Srikar"));
		empSet.add(new Employee(109,"Ruby","Sowmya"));
		
		System.out.println(empSet);
		
	}

}
