package com.programs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StringFrequency {
	
	public static void main(String[] args) {
		
		List<String> fruits = new ArrayList<String>(Arrays.asList("Apple","apple","guava","apple","mango","mango"));
		
		Map<String, Long> frequency = 
			fruits
			.stream()
			.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		System.out.println(frequency);
		
		
		String fruit = "Apple";
		
		Map<Character,Long> charFrequency = fruit
			.toLowerCase()
			.chars()
			.mapToObj(c -> (char) c)
			.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		
		System.out.println(charFrequency);
		
		int[] a = {1,2,3,4,5};
		Arrays
		.stream(a)
		.filter(n -> n%2==0)
		.forEach(System.out::println);
		
		
		
	}

}
