package com.inner;

public class Test2 {
	
	public static void main(String[] args) {
		
		Bike bike = new Bike();
		bike.start();
		
	}

}
