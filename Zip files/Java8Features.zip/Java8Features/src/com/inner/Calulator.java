package com.inner;

public interface Calulator {
	
	public int add(int a , int b);

}
