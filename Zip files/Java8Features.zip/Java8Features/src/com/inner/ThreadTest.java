package com.inner;

public class ThreadTest {
	
	
	public static void main(String[] args) {
		
		Runnable t1 = new Thread1();
		Thread t = new Thread(t1);
		t.start();
		
		Runnable t2 = new Runnable() {
			@Override
			public void run() {
				System.out.println(Thread.currentThread().getName());
				System.out.println("From thread 2");
			}
		};
		
		Thread th2 = new Thread(t2);
		th2.start();
		
		Runnable t3 = () ->{
			System.out.println("From Thread 3");
			System.out.println(Thread.currentThread().getName());
		};
		Thread th3 = new Thread(t3);
		th3.start();
	}

}

class Thread1 implements Runnable{
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName());
		System.out.println("From Thread");
	}
	
}
