package com.inner;

@FunctionalInterface
public interface Vehicle {
	
	public void start();

	default void stop() {
		System.out.println("stopped");
	}
}
