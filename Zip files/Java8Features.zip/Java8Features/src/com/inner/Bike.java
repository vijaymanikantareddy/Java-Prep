package com.inner;

public class Bike implements Vehicle{
	@Override
	public void start() {
		System.out.println("Started Bike");
	}
}
