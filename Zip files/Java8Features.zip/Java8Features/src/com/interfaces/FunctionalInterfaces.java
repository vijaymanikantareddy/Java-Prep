package com.interfaces;

@FunctionalInterface
public interface FunctionalInterfaces {
	
	void hi();
	
	default void sayHi() {
		System.out.println("Functional interface Hii...");
	}
	
}
