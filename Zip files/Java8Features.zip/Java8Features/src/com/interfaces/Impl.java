package com.interfaces;

public class Impl implements FunctionalInterfaces, Interface2{

	@Override
	public void sayBye() {
		System.out.println("Byee...");
	}

	@Override
	public void defaultMethod() {
		System.out.println("From child default method");
	}
	
	@Override
	public void sayHi() {
		FunctionalInterfaces.super.sayHi();
		Interface2.super.sayHi();
	}

	@Override
	public void hi() {
		// TODO Auto-generated method stub
		
	}
	
	

}
