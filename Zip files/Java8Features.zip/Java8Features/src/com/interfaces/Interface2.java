package com.interfaces;

public interface Interface2{
	
	public void sayBye();
	
	default void sayHi() {
		
		System.out.println("Interface 2 Hii");
	}
	
	default void defaultMethod() {
		System.out.println("From Interface2 Default method");
	}
	
	static void staticMethod() {
		System.out.println("static method");
	}
	
}
