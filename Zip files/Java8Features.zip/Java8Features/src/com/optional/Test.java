package com.optional;

import java.util.Optional;

public class Test {
	
	public static void main(String[] args) {
		
		User user = new User(10,"fayaz");
		User user2 = new User(20,null);
		
		Optional<String> email = user.getUserEmailById(10);
		email.ifPresentOrElse(e -> System.out.println(e),
							  () -> System.out.println("No value"));
		
		
		Optional<Object> empty = Optional.empty();
		
		Optional<String> of = Optional.of("FLM");
		System.out.println(of.get());
		
		Optional<Object> ofNullable = Optional.ofNullable(null);
		ofNullable.ifPresent( n -> System.out.println(n));
		
		Optional<String> name = Optional.of("fayaz");
		
		Optional<Integer> map = name
			.map(String::length);
		
		System.out.println(map.get());
		
	}

}
