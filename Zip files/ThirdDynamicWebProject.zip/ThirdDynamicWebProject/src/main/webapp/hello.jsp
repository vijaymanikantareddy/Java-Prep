<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<h1>This Is JSP Page ...</h1>
<% 
	String name = "Fayaz";
	out.println(name);
%> 
<h1> Hi <%=  name %> You are a bad Tutor </h1> 

</body>
</html>